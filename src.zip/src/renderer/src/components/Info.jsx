function Share(){
    return(
    <div>
        <h1>INFO</h1>
        <p>Welcome to plotgardener, here are a few pointers on utilizing the app.</p>
        <li>
            <p>Wrap strings and character inputs in quotes (i.e. "red")</p>
        </li>
    </div>
)
}
export default Share